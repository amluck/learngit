#ifndef LIB_SOURCE_CORE_POINT_H_
#define LIB_SOURCE_CORE_POINT_H_
/**
 * @file point.h
 * @brief 
 * 
 * @date 2011-01-13
 * @authors Fabio R. Panettieri
 * 
 * @todo Brief and description
 * 
 */

namespace acid_maps {

/**
 * @brief 
 * 
 * @todo Brief and description
 */
struct Point {
  float x;
  float y;
  float value;
};

};  // namespace acid_maps

#endif  //LIB_SOURCE_CORE_POINT_H_

