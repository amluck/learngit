#ifndef LIB_SOURCE_CORE_COLOR_H_
#define LIB_SOURCE_CORE_COLOR_H_
/**
 * @file color.h
 * @brief 
 * 
 * @date 2011-03-14
 * @authors Fabio R. Panettieri
 * 
 * @todo Brief and description
 * 
 */

namespace acid_maps {

/**
 * @brief 
 * 
 * @todo Brief and description
 */
struct Color {
  unsigned char r;
  unsigned char g;
  unsigned char b;
  unsigned char a;
};

};  // namespace acid_maps

#endif  //LIB_SOURCE_CORE_COLOR_H_

