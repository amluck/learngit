#ifndef LIB_SOURCE_CORE_PIXEL_H_
#define LIB_SOURCE_CORE_PIXEL_H_
/**
 * @file pixel.h
 * @brief 
 * 
 * @date 2011-01-13
 * @authors Fabio R. Panettieri
 * 
 * @todo Brief and description
 * 
 */

namespace acid_maps {

/**
 * @brief 
 * 
 * @todo Brief and description
 */
struct Pixel {
  int x;
  int y;
  float value;
};

};  // namespace acid_maps

#endif  //LIB_SOURCE_CORE_PIXEL_H_

